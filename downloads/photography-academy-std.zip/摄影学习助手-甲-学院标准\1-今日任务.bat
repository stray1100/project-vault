@echo off
chcp 65001 >nul
cd /d "%~dp0"
python study_assistant.py today
pause
