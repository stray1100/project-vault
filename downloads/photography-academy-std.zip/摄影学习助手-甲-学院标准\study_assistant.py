# -*- coding: utf-8 -*-
"""摄影学习助手 CLI（纯标准库）。命令：today / quiz / card / stats"""
import csv, json, os, random, sys
from datetime import date, datetime, timedelta
from pathlib import Path

BASE = Path(__file__).resolve().parent
CSV = BASE / "计划总表.csv"
MATS = BASE / "materials.json"
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)
PROG = DATA / "progress.json"
CARDS = DATA / "我的卡片库.csv"

D = ["D1", "D3", "D7", "D14", "D30"]


def load_plan():
    with CSV.open(encoding="utf-8-sig") as f:
        r = list(csv.reader(f))
    return r[0], r[1:]


def load_prog():
    if PROG.exists():
        try:
            return json.loads(PROG.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"done": {}, "quiz": {}, "read": {}}


def save_prog(p):
    PROG.write_text(json.dumps(p, ensure_ascii=False, indent=1), encoding="utf-8")


def load_mats():
    if not MATS.exists():
        return {}
    return json.loads(MATS.read_text(encoding="utf-8")).get("items", {})


def keymap(rows):
    m, new, byday, rev = {}, {}, {}, {}
    for r in rows:
        byday[r[0]] = r
        if r[3] == "新知识点":
            m.setdefault(r[4], 0)
            m[r[4]] += 1
            key = "M%02d-K%02d" % (list(dict.fromkeys(x[4] for x in rows)).index(r[4]) + 1, m[r[4]])
            new[key] = r
            for i in range(11, 16):
                if r[i]:
                    rev.setdefault(r[i], []).append((key, r[5], D[i - 11], r[0], r[17]))
    return new, byday, rev


def rule(t):
    return "-" * max(24, min(56, len(t) * 2))


def show_today():
    _, rows = load_plan()
    new, byday, rev = keymap(rows)
    t = date.today().isoformat()
    if t in byday:
        r = byday[t]
    else:
        first, last = rows[0][0], rows[-1][0]
        print("（今天 %s 不在主周期 %s ~ %s 内，显示最近的边界日）\n" % (t, first, last))
        r = rows[0] if t < first else rows[-1]
    p = load_prog()
    print(rule(r[5]))
    print("第 %s 天 · %s · %s" % (r[2], r[1], r[3]))
    print(r[5])
    print("模块：%s   方向：%s" % (r[4], r[17]))
    print("教材：%s" % (r[6].replace("参考：", "") or "-"))
    print(rule(r[5]))
    if r[3] == "新知识点":
        print("■ 判断要点（今天要验证的一个变量）\n  %s\n" % r[8])
        print("■ 学习目标\n  %s\n" % r[7])
        print("■ 练习任务\n  %s\n" % r[9])
        _key = next((k for k, v in new.items() if v is r), "")
        mat = load_mats().get(_key, {})
        if mat.get("task_card"):
            print("■ 任务卡 · 设定\n  %s\n" % mat["task_card"]["setup"])
            print("■ 任务卡 · 交付\n  %s\n" % mat["task_card"]["deliverable"])
            print("■ 三维评分")
            for x in mat["task_card"]["rubric"]:
                print("  - %s" % x)
            print()
    due = rev.get(t, [])
    if due:
        print("■ 今日到期复习（%d 条）" % len(due))
        for k, title, stage, src, tag in due:
            print("  [%s] %s  (来自 %s · %s)" % (stage, title, src, tag))
        print()
    ok = p["done"].get(t)
    print("状态：%s" % ("已完成 ✓" if ok else "未完成"))
    print("完成标记命令：python study_assistant.py done")


def mark_done():
    t = date.today().isoformat()
    p = load_prog()
    p["done"][t] = {"at": datetime.now().isoformat(timespec="seconds")}
    save_prog(p)
    print("已记录：%s 完成" % t)


def run_quiz():
    _, rows = load_plan()
    new, byday, rev = keymap(rows)
    t = date.today().isoformat()
    pool = []
    if t in byday and byday[t][3] == "新知识点":
        pool += [k for k, v in new.items() if v is byday[t]]
    pool += [x[0] for x in rev.get(t, [])]
    pool = list(dict.fromkeys(pool))
    if not pool:
        print("今天没有待答的题（无新知识点、无到期复习）。")
        return
    mats = load_mats()
    p = load_prog()
    rec = p["quiz"].setdefault(t, {})
    print("共 %d 个知识点待自测。\n" % min(5, len(pool)))
    for key in pool[:5]:
        m = mats.get(key, {})
        print(rule(m.get("title", key)))
        print("【%s】%s" % (key, m.get("title", key)))
        for q in m.get("quiz", [])[:2]:
            print("\nQ: %s" % q["q"])
            input("   （先自己答完，回车看答案）")
            print("A: %s" % q["a"])
            print("为什么：%s" % q["why"])
        while True:
            s = input("\n三档自评 [1]会 [2]模糊 [3]不会：").strip()
            if s in ("1", "2", "3"):
                break
        rec[key] = {"会": "会", "1": "会", "2": "模糊", "3": "不会"}.get(s, "模糊") if s in ("1", "2", "3") else "模糊"
        rec[key] = {"1": "会", "2": "模糊", "3": "不会"}[s]
        print("已记录：%s\n" % rec[key])
    save_prog(p)
    print("本轮自测完成，已写入 data/progress.json")


def show_card():
    mats = load_mats()
    if not mats:
        print("未找到 materials.json")
        return
    keys = sorted(mats.keys())
    if len(sys.argv) > 2 and sys.argv[2] == "random":
        k = random.choice(keys)
        m = mats[k]
        print(rule(m["title"]))
        print("【%s】%s" % (k, m["title"]))
        print("\nQ: 「%s」的判断要点是什么？" % m["title"])
        input("   （回车看答案）")
        print("A: %s" % m.get("anchor", ""))
        print("失败样本：%s" % (m.get("pitfalls") or [""])[0])
        return
    print("共 %d 张卡片" % len(keys))
    for k in keys:
        print("  %s  %s" % (k, mats[k]["title"]))
    print("\n随机抽一张：python study_assistant.py card random")


def show_stats():
    _, rows = load_plan()
    new, byday, rev = keymap(rows)
    p = load_prog()
    today = date.today()
    start = date.fromisoformat(rows[0][0])
    elapsed = max(1, (today - start).days + 1)
    done = len(p["done"])
    # 连续天数
    streak, cur = 0, today
    while True:
        if cur.isoformat() in p["done"]:
            streak += 1
            cur -= timedelta(days=1)
        elif cur == today:
            cur -= timedelta(days=1)
        else:
            break
    backlog = 0
    for d, items in rev.items():
        if d < today.isoformat() and d >= start.isoformat():
            if d not in p["quiz"]:
                backlog += len(items)
    print(rule("统计"))
    print("计划总天数：%d   已完成：%d   区间完成率：%.0f%%" % (len(rows), done, min(100, done / elapsed * 100)))
    print("连续打卡：%d 天   逾期复习：%d 条" % (streak, backlog))
    quiz_n = sum(len(v) for v in p["quiz"].values())
    print("累计自测：%d 个知识点" % quiz_n)
    print()
    print("模块掌握：")
    mods = {}
    for k, r in new.items():
        mods.setdefault(r[4], [0, 0])
        mods[r[4]][1] += 1
        if r[0] in p["done"]:
            mods[r[4]][0] += 1
    for name, (a, b) in mods.items():
        bar = "#" * int(a / b * 20) if b else ""
        print("  %-14s %2d/%-2d %s" % (name, a, b, bar))
    if p["quiz"]:
        agg = {}
        for d, rec in p["quiz"].items():
            for k, s in rec.items():
                tag = new.get(k, ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "综合"])[17] or "综合"
                v = {"会": 5, "模糊": 3, "不会": 1}.get(s, 3)
                agg.setdefault(tag, [0, 0])
                agg[tag][0] += v
                agg[tag][1] += 1
        print("\n题材 × 自评均分（低者优先补）：")
        for tag, (s, n) in sorted(agg.items(), key=lambda x: x[1][0] / x[1][1]):
            print("  %-8s %.1f  (%d 题)" % (tag, s / n, n))


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "today"
    if cmd == "today":
        show_today()
    elif cmd == "done":
        mark_done()
    elif cmd == "quiz":
        run_quiz()
    elif cmd == "card":
        show_card()
    elif cmd == "stats":
        show_stats()
    else:
        print("用法：python study_assistant.py [today|done|quiz|card|stats]")


if __name__ == "__main__":
    main()
